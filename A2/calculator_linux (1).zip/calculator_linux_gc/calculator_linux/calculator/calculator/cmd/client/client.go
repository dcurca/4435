/*
*Dana Curca
* 250976773
 */
package main

import (
	"bufio"
	"context"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	"google.golang.org/grpc"

	pb "calculator/proto"
)

const (
	portFile   = "port"
	inputFile  = "input"
	outputFile = "output"

	add  string = "add"
	sub  string = "sub"
	div  string = "div"
	mult string = "mult"
)

func main() {
	//open input file and read port number
	inputPort, err := os.Open(portFile)
	if err != nil {
		log.Fatalf("Error opening file: %v", err)
	}
	defer inputPort.Close()

	scanner := bufio.NewScanner(inputPort)
	var port string = ""
	for scanner.Scan() {
		port = scanner.Text()
	}

	//establish a connection with the specified port
	conn, err := grpc.Dial("localhost:"+port, grpc.WithInsecure(), grpc.WithBlock())
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()

	//create the client connection
	c := pb.NewCalculatorClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	input, err := os.Open(inputFile)
	if err != nil {
		log.Fatal(err)
	}
	defer input.Close()

	output, err := os.Create(outputFile)
	if err != nil {
		log.Fatal(err)
	}
	defer output.Close()

	//analyze input file for arithmetic requests
	scanner = bufio.NewScanner(input)
	var lines []string

	for scanner.Scan() {
		lines = append(lines, scanner.Text())
	}
	input.Close()

	for i := range lines {
		splitLines := strings.Split(lines[i], " ")
		op := splitLines[0]
		i := splitLines[1]
		j := splitLines[2]

		x, err1 := strconv.ParseInt(i, 10, 64) //convert string i into variable x int
		y, err2 := strconv.ParseInt(j, 10, 64) //convert string j into variable y int
		if err1 != nil && err2 != nil {
			log.Fatal("Could not convert to float")
		}

		//send x,y pair to server
		req := &pb.IntPair{X: x, Y: y}

		//perform arithmetic with associated input requests and write to output file
		switch op {
		case add:
			res, err := c.Add(ctx, req)
			if err != nil {
				log.Fatalf("Addition was unsuccessful", err)
			}
			_, err = output.WriteString(strconv.FormatInt(res.GetResult(), 10) + "\n")

		case sub:
			res, err := c.Sub(ctx, req)
			if err != nil {
				log.Fatalf("Subtraction was unsuccessful", err)
			}
			_, err = output.WriteString(strconv.FormatInt(res.GetResult(), 10) + "\n")

		case div:
			res, err := c.Div(ctx, req)
			if err != nil {
				log.Fatalf("Division was unsuccessful", err)
			}
			_, err = output.WriteString(fmt.Sprintf("%.2f", res.GetResult()) + "\n")

		case mult:
			res, err := c.Mult(ctx, req)
			if err != nil {
				log.Fatalf("Multiplication was unsuccessful", err)
			}
			_, err = output.WriteString(strconv.FormatInt(res.GetResult(), 10) + "\n")

		default:
			log.Fatalf("Invalid operation")
		}
	}
}
