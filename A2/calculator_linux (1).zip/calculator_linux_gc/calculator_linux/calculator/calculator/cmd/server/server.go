package main

import (
	"bufio"
	"context"
	"log"
	"net"
	"os"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"

	pb "calculator/proto"
)

const portFile = "port"

type CalcServer struct {
	pb.UnimplementedCalculatorServer
}

//arithmetic add function
func (c *CalcServer) Add(ctx context.Context, req *pb.IntPair) (*pb.IntResult, error) {
	result := req.GetX() + req.GetY()
	return &pb.IntResult{Result: result}, nil
}

//arithmetic sub function
func (c *CalcServer) Sub(ctx context.Context, req *pb.IntPair) (*pb.IntResult, error) {
	result := req.GetX() - req.GetY()
	return &pb.IntResult{Result: result}, nil
}

//arithmetic mult function
func (c *CalcServer) Mult(ctx context.Context, req *pb.IntPair) (*pb.IntResult, error) {
	result := req.GetX() * req.GetY()
	return &pb.IntResult{Result: result}, nil
}

//arithmetic div function 
func (c *CalcServer) Div(ctx context.Context, req *pb.IntPair) (*pb.IntResultFloat, error) {
	result := float32(req.GetX()) / float32(req.GetY())
	return &pb.IntResultFloat{Result: result}, nil
}

func main() {
	//scan port file for port number
	inputPort, err := os.Open(portFile)
	if err != nil {
		log.Fatalf("Error opening file: %v", err)
	}
	defer inputPort.Close()

	scanner := bufio.NewScanner(inputPort)
	var port string = ""
	for scanner.Scan() {
		port = scanner.Text()
	}

	//establish a tcp connection via the port number
	lis, err := net.Listen("tcp", ":"+port)
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	//create a server
	s := grpc.NewServer()
	pb.RegisterCalculatorServer(s, &CalcServer{})

	//send client response of the product/sum/difference/quotient
	reflection.Register(s)

	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
