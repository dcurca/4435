/*
*Dana Curca
*250976773
 */
package main

import (
	"bufio"
	"context"
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	"google.golang.org/grpc"

	pb "bank/proto"
)

const (
	portFile  = "port"
	inputFile = "input"

	deposit  = "deposit"
	withdraw = "withdraw"
	interest = "interest"
)

func main() {
	//read in port number
	inputPort, err := os.Open(portFile)
	if err != nil {
		log.Fatalf("could not open file: %v", err)
	}
	defer inputPort.Close()

	scanner := bufio.NewScanner(inputPort)
	var port string = ""
	if scanner.Scan() {
		port = scanner.Text()
	}

	input, err := os.Open(inputFile)
	if err != nil {
		log.Fatal(err)
	}
	defer input.Close()

	//begin a connection with the specified port number
	conn, err := grpc.Dial("localhost:"+port, grpc.WithInsecure(), grpc.WithBlock())
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()

	//create a new client
	c := pb.NewBankClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	//read in bank account requests
	scanner = bufio.NewScanner(input)
	var lines []string

	for scanner.Scan() {
		lines = append(lines, scanner.Text())
	}
	input.Close()

	for i := range lines {
		splitLines := strings.Split(lines[i], " ")
		op := splitLines[1]
		i := splitLines[2]
		j := splitLines[3]

		//convert strings to correct format
		accnum, err1 := strconv.ParseInt(i, 10, 64)
		amount, err2 := strconv.ParseFloat(j, 32)
		if err1 != nil && err2 != nil {
			log.Fatal("Could not convert to int")
		}

		//request pair sent to server
		req := &pb.AccDetails{AccNum: accnum, Amount: float32(amount)}
		switch op {
		case deposit:
			_, err := c.Deposit(ctx, req)
			if err != nil {
				log.Fatalf("Deposit was unsuccessful: %v", err)
			}
		case withdraw:
			_, err := c.Withdraw(ctx, req)
			if err != nil {
				log.Fatalf("Withdraw was unsuccessful: %v", err)
			}
		case interest:
			_, err := c.AddInterest(ctx, req)
			if err != nil {
				log.Fatalf("Adding Interest was unsuccessful: %v", err)
			}
		default:
			log.Fatalf("Invalid operation provided: %s\n", op)
		}
	}
}
