/*
*Dana Curca
*250976773
*must ctrl-c on server side to update updatedAccounts.json
 */

package main

import (
	"bufio"
	"context"
	"encoding/json"
	"io"
	"log"
	"net"
	"os"
	"os/signal"
	"syscall"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"

	pb "bank/proto"
)

const (
	portFile   = "port"
	inputFile  = "accounts.json"
	outputFile = "updatedAccounts.json"
)

type BankAccount struct {
	Name      *string  `json:"Name"`
	AccountId *int64   `json:"AccountID"`
	Balance   *float32 `json:"Balance"`
}

var accList []BankAccount

type BankServer struct {
	pb.UnimplementedBankServer
}

//withdraw function
func (b *BankServer) Withdraw(ctx context.Context, req *pb.AccDetails) (*pb.AccResponse, error) {
	for _, acc := range accList {
		if *acc.AccountId == req.GetAccNum() {
			*acc.Balance -= req.GetAmount()
		}
	}
	return &pb.AccResponse{}, nil
}

//deposit function
func (b *BankServer) Deposit(ctx context.Context, req *pb.AccDetails) (*pb.AccResponse, error) {
	for _, acc := range accList {
		if *acc.AccountId == req.GetAccNum() {
			*acc.Balance += req.GetAmount()
		}
	}
	return &pb.AccResponse{}, nil
}

//add interest function
func (b *BankServer) AddInterest(ctx context.Context, req *pb.AccDetails) (*pb.AccResponse, error) {
	for _, acc := range accList {
		if *acc.AccountId == req.GetAccNum() {
			*acc.Balance += *acc.Balance * (req.Amount / 100)
		}
	}
	return &pb.AccResponse{}, nil
}

func main() {
	//read in port number
	inputPort, err := os.Open(portFile)
	if err != nil {
		log.Fatalf("Error opening file: %v", err)
	}
	defer inputPort.Close()

	scanner := bufio.NewScanner(inputPort)
	var port string = ""
	if scanner.Scan() {
		port = scanner.Text()
	}

	input, err := os.Open(inputFile)
	if err != nil {
		log.Fatal(err)
	}
	defer input.Close()

	output, err := os.Create(outputFile)
	if err != nil {
		log.Fatal(err)
	}
	defer output.Close()

	byteValues, err := io.ReadAll(input)
	if err != nil {
		log.Fatalf("Error reading json file %v", err)
	}

	err = json.Unmarshal(byteValues, &accList)
	if err != nil {
		log.Fatalf("Unmarshalling is unsuccessful: %v", err)
	}

	lis, err := net.Listen("tcp", ":"+port)
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	//create a new server
	s := grpc.NewServer()
	pb.RegisterBankServer(s, &BankServer{})

	reflection.Register(s)

	//OS signals
	sigs := make(chan os.Signal)
	done := make(chan error)

	signal.Notify(sigs, syscall.SIGTERM, syscall.SIGINT)

	//begin server listen
	go func() {
		err = s.Serve(lis)
		if err != nil {
			log.Fatalf("failed to listen: %v", err)
		}
	}()

	defer func() {
		//marshal bytes and write into output file
		byteValues, _ := json.Marshal(&accList)
		_, err = output.Write(byteValues)
		if err != nil {
			log.Printf("Output file could not be written to, please try again: %v", err)
		}
		s.GracefulStop()
	}()

	//delay server shutdown until os signal
	select {
	case <-done:
		return
	case <-sigs:
		return
	}
}
