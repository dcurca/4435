/*
*Dana Curca 250976773
*Assignment 2
 */

package main

import (
	"bufio"
	"context"
	"log"
	"net"
	"os"
	"strings"
	"time"

	"github.com/hashicorp/consul/api"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"

	pb "lamportClocks/proto"
)

var doneCount int

const (
	deposit  = "deposit"
	withdraw = "withdraw"
	interest = "interest"
	accJSON  = "accounts.json"
)

type ops struct {
	operation string
	timestamp string
}

type node struct {
	Name    string
	Addr    string
	NodeNum string

	localList  []string
	globalList []ops

	SDAddress string
	SDKV      api.KV

	Clients map[string]pb.LamportClockClient
	pb.UnsafeLamportClockServer
}

type BankAccount struct {
	Name      *string  `json:"Name"`
	AccountId *int64   `json:"AccountID"`
	Balance   *float32 `json:"Balance"`
}

var accList []BankAccount

type LamportClockServer struct {
	pb.UnimplementedLamportClockServer
}

func (n *node) Exchange(ctx context.Context, in *pb.LamportDetails) (*pb.LamportResponse, error) {
	return &pb.LamportResponse{}, nil
}

func (n *node) StartListening() {
	lis, err := net.Listen("tcp", n.Addr)
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	_n := grpc.NewServer()

	pb.RegisterLamportClockServer(_n, n)
	reflection.Register(_n)

	if err := _n.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}

func (n *node) registerService() {
	config := api.DefaultConfig()
	config.Address = n.SDAddress
	consul, err := api.NewClient(config)
	if err != nil {
		log.Panicln("Unable to contact Service Discovery.")
	}
	kv := consul.KV()
	p := &api.KVPair{Key: n.Name, Value: []byte(n.Addr)}
	_, err = kv.Put(p, nil)
	if err != nil {
		log.Panicln("Unable to register with Service Discovery.")
	}
	n.SDKV = *kv

	log.Println("Successfully registered with Consul.")
}

func (n *node) Start() {
	n.Clients = make(map[string]pb.LamportClockClient)

	go n.StartListening()

	n.registerService()

	for i := 1; i < len(n.localList); i++ {
		var x = ops{operation: n.localList[i], timestamp: string(i) + "." + n.NodeNum}
		n.globalList = append(n.globalList, x)
	}

	for {
		time.Sleep(10 * time.Second)
		n.GreetAll()
		time.Sleep(10 * time.Second)
		break
		//if doneCount == len(n.Clients)-1 {
		//sort.Slice(n.globalList[2], func(i, j int) bool {

		//}
		//}
	}
}

func (n *node) SetupClient(name string, addr string, operation ops) {
	conn, err := grpc.Dial(addr, grpc.WithInsecure())
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()
	n.Clients[name] = pb.NewLamportClockClient(conn)

	r, err := n.Clients[name].Exchange(context.Background(), &pb.LamportDetails{Op: operation.operation, LamportTimestamp: operation.timestamp})
	if err != nil {
		log.Fatalf("could not greet: %v", err)
	}
	log.Printf("Sending: %s", r)

}

func (n *node) GreetAll() {
	kvpairs, _, err := n.SDKV.List("dcurca", nil)
	if err != nil {
		log.Panicln(err)
		return
	}

	for _, kventry := range kvpairs {
		if strings.Compare(kventry.Key, n.Name) == 0 {
			continue
		}
		if strings.Compare(kventry.Key, n.Name) != 0 {
			n.SetupClient(kventry.Key, string(kventry.Value), n.globalList[2])
		}
	}
}

func (n *node) MessagesRecieved(ctx context.Context, in *pb.LamportDetails) (*pb.LamportResponse, error) {
	var y = ops{operation: in.GetOp(), timestamp: in.GetLamportTimestamp()}
	n.globalList = append(n.globalList, y)

	if in.GetOp() == "done" {
		doneCount += 1
	}

	return &pb.LamportResponse{}, nil
}

func main() {
	args := os.Args[1:]
	if len(args) != 4 {
		log.Fatal("Invalid number of arguments, please try again with 3 arguments")
	}
	name := args[0]

	var nodeNum string = ""
	nameSplit := strings.Split(name, " ")
	nodeNum = nameSplit[1]

	listenaddr := args[1]
	sdaddress := args[2]
	operationsFile := args[3]

	accountsJSON, err := os.Open(accJSON)
	if err != nil {
		log.Fatal(err)
	}
	defer accountsJSON.Close()

	localOpsList, err := os.Open(operationsFile)
	if err != nil {
		log.Fatal(err)
	}
	defer localOpsList.Close()

	scanner := bufio.NewScanner(localOpsList)
	var lines []string

	for scanner.Scan() {
		lines = append(lines, scanner.Text())
	}
	localOpsList.Close()

	for i := range lines {
		print("this is what is in the file:", i)
	}

	var globalOpsList []ops

	noden := node{Name: name, Addr: listenaddr, NodeNum: nodeNum, localList: lines, globalList: globalOpsList, SDAddress: sdaddress, Clients: nil}

	noden.Start()
}
